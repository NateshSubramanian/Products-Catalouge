package com.productCatalogue.dao;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.stereotype.Component;

@Component
public class ProductDAO {
	final static Logger logger = Logger.getLogger(ProductDAO.class);

	/**
	 * This method is use to read json file from resource folder
	 * 
	 * @return
	 * @throws IOException
	 * @throws ParseException
	 */
	public JSONArray readJsonFileProduct() throws IOException, ParseException {
		logger.info("read json file : readJsonFileProduct()");
		JSONParser parse = new JSONParser();
		JSONObject jobj = null;
		String content = null;
		String fileName = "config/products.json";
		JSONArray productJsonArray = null;
		ClassLoader classLoader = new ProductDAO().getClass().getClassLoader();
		File file = new File(classLoader.getResource(fileName).getFile());
		// Read File Content
		try {
			content = new String(Files.readAllBytes(file.toPath()));
			jobj = (JSONObject) parse.parse(content);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		productJsonArray = (JSONArray) jobj.get("products");
		return productJsonArray;

	}
}