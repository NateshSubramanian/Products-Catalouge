package com.productCatalogue.bean;

import com.productCatalogue.bean.ColorSwatches;

public class Product {

	String productId;
	String title;
	String nowPrice;
	ColorSwatches colorSwiches;
	String priceLabel;
	Double priceReduction=0.00;
	
	
	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}


	public String getTitle() {
		return title;
	}

	public String getPriceLabel() {
		return priceLabel;
	}

	public void setPriceLabel(String priceLabel) {
		this.priceLabel = priceLabel;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getNowPrice() {
		return nowPrice;
	}

	
	public void setNowPrice(String nowPrice) {
		this.nowPrice = nowPrice;
	}
	
	public ColorSwatches getColorSwiches() {
		return colorSwiches;
	}

	public void setColorSwiches(ColorSwatches colorSwiches) {
		this.colorSwiches = colorSwiches;
	}

	public Double getPriceReduction() {
		return priceReduction;
	}

	public void setPriceReduction(Double priceReduction) {
		this.priceReduction = priceReduction;
	}
	
	

	
	}
