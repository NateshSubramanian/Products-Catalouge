package com.productCatalogue.bean;

public class PriceLabel {

	String ShowWasNow;
	String ShowWasThenNow;
	String ShowPercDscount;

	public String getShowWasNow() {
		return ShowWasNow;
	}

	public void setShowWasNow(String showWasNow) {
		ShowWasNow = showWasNow;
	}

	public String getShowWasThenNow() {
		return ShowWasThenNow;
	}

	public void setShowWasThenNow(String showWasThenNow) {
		ShowWasThenNow = showWasThenNow;
	}

	public String getShowPercDscount() {
		return ShowPercDscount;
	}

	public void setShowPercDscount(String showPercDscount) {
		ShowPercDscount = showPercDscount;
	}

}
