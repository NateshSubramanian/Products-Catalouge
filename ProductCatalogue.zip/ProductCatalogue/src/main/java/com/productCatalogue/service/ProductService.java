package com.productCatalogue.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Hashtable;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.productCatalogue.bean.ColorSwatches;
import com.productCatalogue.bean.Price;
import com.productCatalogue.bean.Product;
import com.productCatalogue.constant.ProdutConstant;
import com.productCatalogue.dao.ProductDAO;

@Service
public class ProductService {

	final static Logger logger = Logger.getLogger(ProductService.class);

	@Autowired
	private ProductDAO productDAO;

	/**
	 * This method is use to get product details
	 * 
	 * @param labelType
	 * @return
	 * @throws IOException
	 * @throws ParseException
	 */
	public List<Product> getProductDetails(String labelType) throws IOException, ParseException {

		logger.info("getProductDetail From service:getProductDetails() : " + labelType);
		List<Product> listProduct = new ArrayList<Product>();
		JSONArray productJsonArray = productDAO.readJsonFileProduct();
		if (!isNotEmpty(labelType)) {
			labelType = "ShowWasNow";
		}
		listProduct = getProductListFromJsonArray(productJsonArray, labelType);

		return listProduct;

	}

	/**
	 * This method is use to get price label
	 * 
	 * @param labeTypeValue
	 * @param price
	 * @return
	 */
	private String getPriceLabel(String labeTypeValue, Price price) {
		logger.info("getPriceLabel details :getPriceLabel()");
		String then;
		StringBuffer priceLabel = new StringBuffer();
		if (isNotEmpty(labeTypeValue)) {
			if (labeTypeValue.equalsIgnoreCase("ShowWasNow")) {
				priceLabel.append("Was ");
				if (price.getWas() != null && !price.getWas().isEmpty()) {
					priceLabel.append("£" + price.getWas());
				}
				priceLabel.append(",now ");
				if (price.getNow() != null && !price.getNow().isEmpty()) {
					if (price.getNow().contains("from")) {
						priceLabel.append(price.getNow());
					} else {
						priceLabel.append("£" + price.getNow());
					}

				}
			} else if (labeTypeValue.equalsIgnoreCase("ShowWasThenNow")) {
				if (price.getThen2() != null) {
					then = price.getThen2();
				} else {
					then = price.getThen1();
				}
				priceLabel.append("Was ");
				if (price.getWas() != null && !price.getWas().isEmpty()) {
					priceLabel.append("£" + price.getWas());
				}
				priceLabel.append(",then ");
				if (then != null && then.isEmpty()) {
					priceLabel.append("£" + then);
				}
				priceLabel.append(",now ");
				if (price.getNow() != null && !price.getNow().isEmpty()) {
					priceLabel.append("£" + price.getNow());
				}
			} else if (labeTypeValue.equalsIgnoreCase("ShowPercDscount")) {
				if (!price.getNow().contains("from")) {
					Double now = new Double(price.getNow().substring(1, price.getNow().length()));
					Double discount = now * .10;
					priceLabel.append("£" + discount.toString());
				}
			}
		}
		return priceLabel.toString();
	}

	/**
	 * @param colorSwatchesArray
	 * @return
	 */
	private ColorSwatches getColorSwatches(JSONArray colorSwatchesArray) {

		logger.info("getColorSwatches details:getColorSwatches()");
		ColorSwatches colorSwatshes = null;
		Hashtable<String, String> rgb = new Hashtable<String, String>();
		if (colorSwatchesArray != null) {
			for (int i = 0; i < colorSwatchesArray.size(); i++) {
				colorSwatshes = new ColorSwatches();
				JSONObject colorSwatches = (JSONObject) colorSwatchesArray.get(i);
				colorSwatshes.setColor(colorSwatches.get("color").toString());
				colorSwatshes.setSkuId(colorSwatches.get("skuId").toString());
				rgb = getRGBColorValues();
				if (rgb.containsKey(colorSwatches.get("basicColor").toString())) {
					colorSwatshes.setRgbColor(rgb.get(colorSwatches.get("basicColor").toString()));
				}
			}
		}
		return colorSwatshes;
	}

	private Hashtable<String, String> getRGBColorValues() {

		logger.info("getHashtable RGB color code :getRGBColorValues()");
		Hashtable<String, String> hm = new Hashtable<String, String>();
		hm.put(ProdutConstant.COLOR_NAME_BLUE, ProdutConstant.COLOR_BLUE_CODE);
		hm.put(ProdutConstant.COLOR_NAME_WHITE, ProdutConstant.COLOR_WHITE_CODE);
		hm.put(ProdutConstant.COLOR_NAME_RED, ProdutConstant.COLOR_RED_CODE);
		hm.put(ProdutConstant.COLOR_NAME_GREEN, ProdutConstant.COLOR_GREEN_CODE);
		hm.put(ProdutConstant.COLOR_NAME_GRAY, ProdutConstant.COLOR_GRAY_CODE);
		hm.put(ProdutConstant.COLOR_NAME_BLACK, ProdutConstant.COLOR_BLACK_CODE);
		hm.put(ProdutConstant.COLOR_NAME_ORANGE, ProdutConstant.COLOR_ORANGE_CODE);
		hm.put(ProdutConstant.COLOR_NAME_PINK, ProdutConstant.COLOR_PINK_CODE);
		hm.put(ProdutConstant.COLOR_NAME_YELLOW, ProdutConstant.COLOR_YELLOW_CODE);
		hm.put(ProdutConstant.COLOR_NAME_PURPLE, ProdutConstant.COLOR_PURPLE_CODE);
		return hm;

	}

	/**
	 * This method is use to get list of products from json array
	 * 
	 * @param productJsonArray
	 * @param labelType
	 * @return
	 */
	private List<Product> getProductListFromJsonArray(JSONArray productJsonArray, String labelType) {

		logger.info("get Product list values :getProductListFromJsonArray()");

		List<Product> listProduct = new ArrayList<Product>();

		for (int i = 0; i < productJsonArray.size(); i++) {
			Product product = new Product();
			JSONObject productJsonObj = (JSONObject) productJsonArray.get(i);
			product.setProductId(productJsonObj.get("productId").toString());
			product.setTitle(productJsonObj.get("title").toString());
			JSONArray colorSwitches = (JSONArray) productJsonObj.get("colorSwatches");
			ColorSwatches colorSwatches = getColorSwatches(colorSwitches);
			// setting the price value
			Price priceDetail = new Price();
			JSONObject priceObject = (JSONObject) productJsonObj.get("price");
			if (priceObject.get("now").toString().contains("from")
					&& priceObject.get("now").toString().contains("to")) {
				JSONObject nowObject = (JSONObject) priceObject.get("now");
				priceDetail.setNowFrom(nowObject.get("from").toString());
				priceDetail.setNowTo(nowObject.get("to").toString());
				priceDetail.setNow("from £" + priceDetail.getNowFrom() + ", to £" + priceDetail.getNowTo());
			} else {
				priceDetail.setNow("£" + priceObject.get("now").toString());
				if (isNotEmpty(priceObject.get("now").toString()) && isNotEmpty(priceObject.get("was").toString())) {
					Double priceNow = new Double(priceObject.get("now").toString());
					Double priceWas = new Double(priceObject.get("was").toString());
					product.setPriceReduction(priceWas - priceNow);
				}
			}
			priceDetail.setWas(priceObject.get("was").toString());
			priceDetail.setThen1(priceObject.get("then1").toString());
			priceDetail.setThen2(priceObject.get("then2").toString());
			priceDetail.setUom(priceObject.get("uom").toString());
			priceDetail.setCurrency(priceObject.get("currency").toString());
			String priceLabel = getPriceLabel(labelType, priceDetail);

			product.setPriceLabel(priceLabel);
			product.setNowPrice(priceDetail.getNow());
			product.setColorSwiches(colorSwatches);
			listProduct.add(product);
		}

		List<Product> sortedlistProduct = listProduct.stream()
				.sorted(Comparator.comparing(Product::getPriceReduction).reversed()).collect(Collectors.toList());
		return sortedlistProduct;

	}

	private boolean isNotEmpty(String value) {
		if (value != null && !value.isEmpty()) {
			return true;
		}
		return false;
	}

}
