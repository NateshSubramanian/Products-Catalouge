package com.productCatalogue.constant;

public class ProdutConstant {

	public static String COLOR_BLUE_CODE = "#0000FF";
	public static String COLOR_WHITE_CODE = "#FFFFFF";
	public static String COLOR_RED_CODE = "#FF0000";
	public static String COLOR_GREEN_CODE = "#00FF00";
	public static String COLOR_GRAY_CODE = "#808080";
	public static String COLOR_BLACK_CODE = "#000000";
	public static String COLOR_ORANGE_CODE = "#FFA500";
	public static String COLOR_PINK_CODE = "#FFC0CB";
	public static String COLOR_PURPLE_CODE = "#800080";
	public static String COLOR_YELLOW_CODE = "#FFFF00";

	public static String COLOR_NAME_BLUE = "Blue";
	public static String COLOR_NAME_WHITE = "White";
	public static String COLOR_NAME_RED = "Red";
	public static String COLOR_NAME_GREEN = "Green";
	public static String COLOR_NAME_GRAY = "Gray";
	public static String COLOR_NAME_BLACK = "Black";
	public static String COLOR_NAME_ORANGE = "Orange";
	public static String COLOR_NAME_PINK = "Pink";
	public static String COLOR_NAME_PURPLE = "Purple";
	public static String COLOR_NAME_YELLOW = "Yellow";

}
