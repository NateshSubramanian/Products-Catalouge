package com.productCatalogue;

import org.apache.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class ProductCatalogueApplication {

	final static Logger logger = Logger.getLogger(ProductCatalogueApplication.class);

	/**
	 * This is ProductCatalogue Application  main method
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		@SuppressWarnings("unused")
		ApplicationContext ctx = SpringApplication.run(ProductCatalogueApplication.class, args);
	}

}
